

<?php $__env->startSection('title', __('order.Orders_List')); ?>
<?php $__env->startSection('content-header', __('order.Orders_List')); ?>
<?php $__env->startSection('content-actions'); ?>
    <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-primary"><?php echo e(__('cart.title')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-7"></div>
                <div class="col-md-5">
                    <form action="<?php echo e(route('orders.index')); ?>">
                        <div class="row">
                            <div class="col-md-5">
                                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>" />
                            </div>
                            <div class="col-md-5">
                                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>" />
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-outline-primary" type="submit"><?php echo e(__('order.submit')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <table class="table">
                <thead>
                <tr>
                    <th><?php echo e(__('order.ID')); ?></th>
                    <th><?php echo e(__('order.Customer_Name')); ?></th>
                    <th>Branch</th>
                    <th>Counter</th>
                    <th><?php echo e(__('order.Total')); ?></th>
                    <th><?php echo e(__('order.Received_Amount')); ?></th>
                    <th><?php echo e(__('order.Status')); ?></th>
                    <th><?php echo e(__('order.To_Pay')); ?></th>
                    <th><?php echo e(__('order.Created_At')); ?></th>
                    <th><?php echo e(__('order.Actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $orderTotal = $order->total();
                        $orderReceived = $order->receivedAmount();
                        $orderRemaining = $orderTotal - $orderReceived;
                    ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->getCustomerName()); ?></td>
                        <td><?php echo e($order->branch?->name ?? '—'); ?> <small class="text-muted"><?php echo e($order->branch?->code); ?></small></td>
                        <td><?php echo e($order->counter?->name ?? '—'); ?> <small class="text-muted"><?php echo e($order->counter?->code); ?></small></td>
                        <td><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($orderTotal, 2)); ?></td>
                        <td><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($orderReceived, 2)); ?></td>
                        <td>
                            <?php if($orderReceived == 0): ?>
                                <span class="badge badge-danger"><?php echo e(__('order.Not_Paid')); ?></span>
                            <?php elseif($orderReceived < $orderTotal): ?>
                                <span class="badge badge-warning"><?php echo e(__('order.Partial')); ?></span>
                            <?php elseif($orderReceived >= $orderTotal): ?>
                                <span class="badge badge-success"><?php echo e(__('order.Paid')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($orderRemaining, 2)); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td>
                            <button
                                class="btn btn-sm btn-secondary btnShowInvoice"
                                data-toggle="modal"
                                data-target="#modalInvoice"
                                data-order-id="<?php echo e($order->id); ?>"
                                data-invoice-no="<?php echo e($order->invoice_no ?? 'POS-' . str_pad($order->id, 4, '0', STR_PAD_LEFT)); ?>"
                                data-customer-name="<?php echo e($order->getCustomerName()); ?>"
                                data-branch-name="<?php echo e($order->branch?->name ?? '—'); ?>"
                                data-branch-code="<?php echo e($order->branch?->code ?? ''); ?>"
                                data-counter-name="<?php echo e($order->counter?->name ?? '—'); ?>"
                                data-counter-code="<?php echo e($order->counter?->code ?? ''); ?>"
                                data-total="<?php echo e($orderTotal); ?>"
                                data-subtotal="<?php echo e($order->subtotal ?? $orderTotal); ?>"
                                data-tax-percent="<?php echo e($order->tax_percent ?? 0); ?>"
                                data-tax-amount="<?php echo e($order->tax_amount ?? 0); ?>"
                                data-discount-percent="<?php echo e($order->discount_percent ?? 0); ?>"
                                data-discount-amount="<?php echo e($order->discount_amount ?? 0); ?>"
                                data-srb-invoice-id="<?php echo e($order->srb_invoice_id ?? ''); ?>"
                                data-srb-qr-link="<?php echo e($order->srb_qr_code_link ?? ''); ?>"
                                data-received="<?php echo e($orderReceived); ?>"
                                data-items="<?php echo e(base64_encode($order->items->toJson())); ?>"
                                data-created-at="<?php echo e($order->created_at); ?>">
                                <ion-icon size="small" name="eye"></ion-icon>
                            </button>
                            <button
                                type="button"
                                class="btn btn-sm btn-primary btnPrintOrder"
                                data-order-id="<?php echo e($order->id); ?>"
                                data-invoice-no="<?php echo e($order->invoice_no ?? 'POS-' . str_pad($order->id, 4, '0', STR_PAD_LEFT)); ?>"
                                data-customer-name="<?php echo e($order->getCustomerName()); ?>"
                                data-branch-name="<?php echo e($order->branch?->name ?? '-'); ?>"
                                data-counter-name="<?php echo e($order->counter?->name ?? '-'); ?>"
                                data-total="<?php echo e($orderTotal); ?>"
                                data-subtotal="<?php echo e($order->subtotal ?? $orderTotal); ?>"
                                data-tax-percent="<?php echo e($order->tax_percent ?? 0); ?>"
                                data-tax-amount="<?php echo e($order->tax_amount ?? 0); ?>"
                                data-discount-percent="<?php echo e($order->discount_percent ?? 0); ?>"
                                data-discount-amount="<?php echo e($order->discount_amount ?? 0); ?>"
                                data-received="<?php echo e($orderReceived); ?>"
                                data-items="<?php echo e(base64_encode($order->items->toJson())); ?>"
                                data-created-at="<?php echo e($order->created_at); ?>"
                                data-srb-invoice-id="<?php echo e($order->srb_invoice_id ?? ''); ?>"
                                data-srb-qr-link="<?php echo e($order->srb_qr_code_link ?? ''); ?>"
                                title="Print receipt">
                                <i class="fas fa-print"></i>
                            </button>

                            <?php if($orderRemaining > 0): ?>
                                <button class="btn btn-sm btn-primary btnPartialPayment"
                                        data-toggle="modal"
                                        data-target="#partialPaymentModal"
                                        data-order-id="<?php echo e($order->id); ?>"
                                        data-remaining-amount="<?php echo e($orderRemaining); ?>">
                                    Pay Partial
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($total, 2)); ?></th>
                    <th><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($receivedAmount, 2)); ?></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
            <?php echo e($orders->render()); ?>

        </div>
    </div>

    <!-- Partial Payment Modal -->
    <div class="modal fade" id="partialPaymentModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Pay Partial Amount</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('orders.partial-payment')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="order_id" id="modalOrderId">
                        <div class="form-group">
                            <label for="partialAmount">Enter Amount to Pay</label>
                            <input type="number" class="form-control" step="0.01" id="partialAmount" name="amount" required>
                            <small class="form-text text-muted">Remaining: <span id="remainingAmount"></span></small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit Payment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('model'); ?>
    <!-- Invoice Modal -->
    <div class="modal fade" id="modalInvoice" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Invoice</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Dynamic content will be inserted here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="btnPrintInvoice">
                        <i class="fas fa-print mr-1"></i> Print Receipt
                    </button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="module" src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons/ionicons.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        jQuery(document).ready(function($) {
            var currencySymbol = '<?php echo e(config("settings.currency_symbol")); ?>';
            var currentInvoiceButton = null;

            function getOrderItems(button) {
                try {
                    return JSON.parse(atob(button.attr('data-items') || '')) || [];
                } catch (error) {
                    return [];
                }
            }

            // Invoice Modal
            $(document).on('click', '.btnShowInvoice', function() {
                var button = $(this);
                currentInvoiceButton = button;
                var orderId = button.data('order-id');
                var invoiceNo = button.data('invoice-no');
                var customerName = button.data('customer-name');
                var branchName = button.data('branch-name');
                var branchCode = button.data('branch-code');
                var counterName = button.data('counter-name');
                var counterCode = button.data('counter-code');
                var totalAmount = button.data('total');
                var subtotalAmount = button.data('subtotal');
                var taxPercent = button.data('tax-percent') || 0;
                var taxAmount = button.data('tax-amount') || 0;
                var discountPercent = button.data('discount-percent') || 0;
                var discountAmount = button.data('discount-amount') || 0;
                var receivedAmount = button.data('received');
                var createdAt = button.data('created-at');
                var items = getOrderItems(button);

                console.log('Items:', items);

                var statusBadge = '';
                if (receivedAmount == 0) {
                    statusBadge = '<span class="badge badge-danger">Not Paid</span>';
                } else if (receivedAmount < totalAmount) {
                    statusBadge = '<span class="badge badge-warning">Partial</span>';
                } else {
                    statusBadge = '<span class="badge badge-success">Paid</span>';
                }

                var itemsHTML = '';
                if (items && Array.isArray(items) && items.length > 0) {
                    items.forEach(function(item, index) {
                        var isService = Number(item.item_type) === 1 || item.item_type === 'service';
                        var product = item.product || {};
                        var itemName = item.item_name || (isService ? 'Service' : (product.name || 'N/A'));
                        var quantity = item.quantity || 0;
                        var itemTotal = item.price || 0;

                        itemsHTML += '<tr>' +
                            '<td>' + (index + 1) + '</td>' +
                            '<td>' + itemName + '</td>' +
                            '<td>' + (isService ? 'Service' : 'Product') + '</td>' +
                            '<td>' + currencySymbol + ' ' + (quantity ? (parseFloat(itemTotal / quantity)).toFixed(2) : '0.00') + '</td>' +
                            '<td>' + quantity + '</td>' +
                            '<td>' + currencySymbol + ' ' + parseFloat(itemTotal).toFixed(2) + '</td>' +
                            '</tr>';
                    });
                } else {
                    itemsHTML = '<tr><td colspan="6" class="text-center">No items found</td></tr>';
                }

                var modalBody = $('#modalInvoice').find('.modal-body');
                modalBody.html(
                    '<div class="card">' +
                    '<div class="card-header">' +
                    'Invoice <strong>#' + orderId + '</strong>' +
                    '<span class="ml-3">Invoice No: <strong>' + invoiceNo + '</strong></span>' +
                    '<span class="float-right"><strong>Status:</strong> ' + statusBadge + '</span>' +
                    '</div>' +
                    '<div class="card-body">' +
                    '<div class="row mb-4">' +
                    '<div class="col-sm-6">' +
                    '<h6 class="mb-3">To: <strong>' + customerName + '</strong></h6>' +
                    '<div>Date: ' + createdAt + '</div>' +
                    '</div>' +
                    '<div class="col-sm-6 text-sm-right">' +
                    '<div>Branch: <strong>' + branchName + '</strong>' + (branchCode ? ' (' + branchCode + ')' : '') + '</div>' +
                    '<div>Counter: <strong>' + counterName + '</strong>' + (counterCode ? ' (' + counterCode + ')' : '') + '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="table-responsive">' +
                    '<table class="table table-striped">' +
                    '<thead>' +
                    '<tr>' +
                    '<th>#</th>' +
                    '<th>Item</th>' +
                    '<th>Description</th>' +
                    '<th>Unit Cost</th>' +
                    '<th>Qty</th>' +
                    '<th>Total</th>' +
                    '</tr>' +
                    '</thead>' +
                    '<tbody>' + itemsHTML + '</tbody>' +
                    '<tfoot>' +
                    '<tr>' +
                    '<th colspan="5" class="text-right">Subtotal</th>' +
                    '<th>' + currencySymbol + ' ' + parseFloat(subtotalAmount).toFixed(2) + '</th>' +
                    '</tr>' +
                    '<tr>' +
                    '<th colspan="5" class="text-right">Tax (' + parseFloat(taxPercent).toFixed(2) + '%)</th>' +
                    '<th>' + currencySymbol + ' ' + parseFloat(taxAmount).toFixed(2) + '</th>' +
                    '</tr>' +
                    '<tr>' +
                    '<th colspan="5" class="text-right">Discount (' + parseFloat(discountPercent).toFixed(2) + '%)</th>' +
                    '<th>- ' + currencySymbol + ' ' + parseFloat(discountAmount).toFixed(2) + '</th>' +
                    '</tr>' +
                    '<tr>' +
                    '<th colspan="5" class="text-right">Total</th>' +
                    '<th>' + currencySymbol + ' ' + parseFloat(totalAmount).toFixed(2) + '</th>' +
                    '</tr>' +
                    '<tr>' +
                    '<th colspan="5" class="text-right">Paid</th>' +
                    '<th>' + currencySymbol + ' ' + parseFloat(receivedAmount).toFixed(2) + '</th>' +
                    '</tr>' +
                    '<tr>' +
                    '<th colspan="5" class="text-right">Balance</th>' +
                    '<th>' + currencySymbol + ' ' + parseFloat(totalAmount - receivedAmount).toFixed(2) + '</th>' +
                    '</tr>' +
                    '</tfoot>' +
                    '</table>' +
                    '</div>' +
                    '</div>' +
                    '</div>'
                );
            });

            $('#btnPrintInvoice').on('click', function() {
                printThermalReceipt(currentInvoiceButton);
            });

            function printThermalReceipt(button) {
                if (!button || !button.length) return;
                var orderId = button.data('order-id');
                var invoiceNo = button.data('invoice-no');
                var customerName = button.data('customer-name') || 'Walk-in Customer';
                var branchName = button.data('branch-name') || 'Main Branch';
                var counterName = button.data('counter-name') || 'Counter 1';
                var subtotal = parseFloat(button.data('subtotal')) || 0;
                var taxPercent = parseFloat(button.data('tax-percent')) || 0;
                var taxAmount = parseFloat(button.data('tax-amount')) || 0;
                var discountPercent = parseFloat(button.data('discount-percent')) || 0;
                var discountAmount = parseFloat(button.data('discount-amount')) || 0;
                var totalAmount = parseFloat(button.data('total')) || 0;
                var receivedAmount = parseFloat(button.data('received')) || 0;
                var changeDue = receivedAmount > totalAmount ? receivedAmount - totalAmount : 0;
                var createdAt = button.data('created-at');
                var srbInvoiceId = button.attr('data-srb-invoice-id') || '';
                var srbQrLink = button.attr('data-srb-qr-link') || '';
                var items = getOrderItems(button);

                var itemsHTML = items.map(function(item) {
                    var isService = Number(item.item_type) === 1 || item.item_type === 'service';
                    var quantity = Number(item.quantity || 0);
                    var lineTotal = Number(item.price || 0);
                    var unitPrice = quantity ? (lineTotal / quantity) : lineTotal;
                    var name = item.item_name || (isService ? 'Service' : ((item.product && item.product.name) || 'Product'));
                    return '<div class="receipt-item-block">' +
                           '<div class="receipt-item-name">' + name + '</div>' +
                           '<div class="receipt-item-row"><span class="col-item"></span><span class="col-qty">' + quantity + '</span><span class="col-price">' + unitPrice.toFixed(2) + '</span><span class="col-total">' + lineTotal.toFixed(2) + '</span></div>' +
                           '</div>';
                }).join('');

                var businessLogo = window.APP.business_logo_url ? '<img class="receipt-business-logo" src="' + window.APP.business_logo_url + '">' : '';
                var srbLogo = window.APP.srb_pos_logo_url && srbInvoiceId ? '<img class="srb-logo" src="' + window.APP.srb_pos_logo_url + '">' : '';
                var srbQr = srbInvoiceId && srbQrLink ? '<div><img class="srb-qr" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(srbQrLink) + '"></div>' : '';

                var srbSection = srbInvoiceId ? '<div class="srb-footer"><div class="srb-row"><div class="srb-logo-cell">' + srbLogo + '</div><div class="srb-code-cell"><div class="srb-label">SRB Invoice No.</div><div class="srb-invoice-id">' + srbInvoiceId + '</div>' + srbQr + '</div></div><div class="srb-verify">Scan to verify this invoice</div></div>' : '';

                var receiptContent = '<div class="thermal-receipt">' +
                    '<div class="receipt-header">' +
                    businessLogo +
                    '<div class="receipt-brand">BEAUTY BY GT</div>' +
                    '<div class="receipt-subbrand">MAKE-UP | HAIR | SKIN</div>' +
                    '<div class="receipt-address">' + branchName + '</div>' +
                    '<div class="receipt-contact">Counter: ' + counterName + '</div>' +
                    '</div>' +
                    '<div class="receipt-divider-double">====================================</div>' +
                    '<div class="receipt-title">THERMAL RECEIPT / CASH MEMO</div>' +
                    '<div class="receipt-divider">------------------------------------</div>' +
                    '<div class="receipt-meta">' +
                    '<div><span>Invoice #:</span><strong>' + invoiceNo + '</strong></div>' +
                    '<div><span>Order ID:</span><strong>#' + orderId + '</strong></div>' +
                    '<div><span>Date:</span><span>' + createdAt + '</span></div>' +
                    '<div><span>Customer:</span><span>' + customerName + '</span></div>' +
                    '</div>' +
                    '<div class="receipt-divider">------------------------------------</div>' +
                    '<div class="receipt-table-head"><span class="col-item">ITEM DESCRIPTION</span><span class="col-qty">QTY</span><span class="col-price">PRICE</span><span class="col-total">AMOUNT</span></div>' +
                    '<div class="receipt-divider">------------------------------------</div>' +
                    itemsHTML +
                    '<div class="receipt-divider">------------------------------------</div>' +
                    '<div class="receipt-summary">' +
                    '<div class="summary-row"><span>SUBTOTAL:</span><span>' + currencySymbol + ' ' + subtotal.toFixed(2) + '</span></div>' +
                    (taxAmount > 0 ? '<div class="summary-row"><span>GST / TAX (' + taxPercent.toFixed(2) + '%):</span><span>' + currencySymbol + ' ' + taxAmount.toFixed(2) + '</span></div>' : '') +
                    (discountAmount > 0 ? '<div class="summary-row"><span>DISCOUNT (' + discountPercent.toFixed(2) + '%):</span><span>-' + currencySymbol + ' ' + discountAmount.toFixed(2) + '</span></div>' : '') +
                    '<div class="receipt-divider">------------------------------------</div>' +
                    '<div class="summary-row grand-total"><span>NET TOTAL:</span><span>' + currencySymbol + ' ' + totalAmount.toFixed(2) + '</span></div>' +
                    '<div class="receipt-divider">------------------------------------</div>' +
                    '<div class="summary-row"><span>CASH PAID:</span><span>' + currencySymbol + ' ' + receivedAmount.toFixed(2) + '</span></div>' +
                    '<div class="summary-row"><span>CHANGE DUE:</span><span>' + currencySymbol + ' ' + changeDue.toFixed(2) + '</span></div>' +
                    '</div>' +
                    '<div class="receipt-divider-double">====================================</div>' +
                    srbSection +
                    '<div class="receipt-footer">' +
                    '<div class="thanks-title">*** THANK YOU FOR VISITING ***</div>' +
                    '<div class="thanks-sub">Beauty by GT — Luxury Salon & Spa</div>' +
                    '<div class="receipt-notice">Please retain this receipt for any queries.</div>' +
                    '<div class="receipt-software">Powered by INPL-POS</div>' +
                    '</div>' +
                    '</div>';

                var printStyle = '<style>' +
                    '@page { size: 80mm auto; margin: 0mm; }' +
                    'body { width: 72mm; margin: 2mm auto; font-family: "Courier New", Courier, monospace, sans-serif; font-size: 11px; line-height: 1.35; color: #000; background: #fff; }' +
                    '.thermal-receipt { width: 100%; box-sizing: border-box; }' +
                    '.receipt-header { text-align: center; margin-bottom: 4px; }' +
                    '.receipt-business-logo { display: block; max-width: 42mm; max-height: 18mm; object-fit: contain; margin: 0 auto 4px; }' +
                    '.receipt-brand { font-size: 15px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase; }' +
                    '.receipt-subbrand { font-size: 9px; font-weight: 700; letter-spacing: 2px; margin-bottom: 3px; color: #333; }' +
                    '.receipt-address, .receipt-contact { font-size: 10px; }' +
                    '.receipt-divider-double, .receipt-divider { text-align: center; font-weight: 700; letter-spacing: -1px; margin: 3px 0; overflow: hidden; white-space: nowrap; }' +
                    '.receipt-title { font-size: 12px; font-weight: 900; text-align: center; letter-spacing: 1px; margin: 3px 0; }' +
                    '.receipt-meta div { display: flex; justify-content: space-between; font-size: 10.5px; line-height: 1.4; }' +
                    '.receipt-table-head { display: grid; grid-template-columns: 1fr 30px 48px 54px; font-weight: 900; font-size: 9.5px; text-align: right; }' +
                    '.receipt-table-head .col-item { text-align: left; }' +
                    '.receipt-item-block { margin: 3px 0; font-size: 10.5px; }' +
                    '.receipt-item-name { font-weight: 700; word-break: break-word; }' +
                    '.receipt-item-row { display: grid; grid-template-columns: 1fr 30px 48px 54px; text-align: right; font-size: 10.5px; }' +
                    '.receipt-summary { font-size: 11px; }' +
                    '.summary-row { display: flex; justify-content: space-between; padding: 1px 0; font-weight: 600; }' +
                    '.grand-total { font-size: 14px; font-weight: 900; padding: 3px 0; }' +
                    '.receipt-footer { text-align: center; margin-top: 6px; font-size: 9.5px; }' +
                    '.thanks-title { font-weight: 800; font-size: 11px; margin-bottom: 2px; }' +
                    '.thanks-sub { font-size: 9.5px; font-weight: 700; }' +
                    '.receipt-notice { font-size: 9px; margin-top: 2px; }' +
                    '.receipt-software { font-size: 8.5px; margin-top: 4px; color: #444; }' +
                    '.srb-footer { text-align: center; padding: 4px 0; margin-top: 4px; }' +
                    '.srb-row { display: flex; align-items: center; justify-content: center; gap: 4mm; }' +
                    '.srb-logo-cell, .srb-code-cell { width: 32mm; min-width: 0; }' +
                    '.srb-logo { display: block; width: 30mm; max-height: 18mm; object-fit: contain; margin: 0 auto; }' +
                    '.srb-label, .srb-verify { font-size: 8.5px; margin-top: 2px; }' +
                    '.srb-invoice-id { font-weight: 700; font-size: 9.5px; margin: 2px 0; word-break: break-all; }' +
                    '.srb-qr { width: 22mm; height: 22mm; display: block; margin: 3px auto; }' +
                    '</style>';

                var printWindow = window.open('', '_blank', 'width=450,height=700');
                printWindow.document.write('<html><head><title>Receipt #' + orderId + '</title>' + printStyle + '</head><body>' + receiptContent + '</body></html>');
                printWindow.document.close();
                printWindow.onload = function() {
                    var images = printWindow.document.images;
                    var pendingImages = Array.prototype.filter.call(images, function(image) { return !image.complete; });
                    var doPrint = function() {
                        printWindow.focus();
                        printWindow.print();
                        printWindow.close();
                    };
                    if (!pendingImages.length) {
                        setTimeout(doPrint, 100);
                        return;
                    }
                    var loaded = 0;
                    pendingImages.forEach(function(image) {
                        image.onload = image.onerror = function() {
                            loaded += 1;
                            if (loaded === pendingImages.length) doPrint();
                        };
                    });
                };
            }

            $(document).on('click', '.btnPrintOrder', function() {
                printThermalReceipt($(this));
            });

            // Partial Payment Modal
            $(document).on('click', '.btnPartialPayment', function() {
                var button = $(this);
                var orderId = button.data('order-id');
                var remainingAmount = button.data('remaining-amount');

                $('#modalOrderId').val(orderId);
                $('#partialAmount').val(remainingAmount).attr('max', remainingAmount);
                $('#remainingAmount').text(currencySymbol + ' ' + parseFloat(remainingAmount).toFixed(2));
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/orders/index.blade.php ENDPATH**/ ?>