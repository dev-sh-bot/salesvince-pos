

<?php $__env->startSection('title', 'Sign In — Beauty by GT'); ?>

<?php $__env->startSection('css'); ?>
<style>
    .invalid-feedback {
        display: block;
        color: #ef4444;
        font-size: 0.78rem;
        margin-top: 4px;
        font-weight: 600;
    }
    .login-box-msg {
        color: #685329;
        font-weight: 700;
        font-size: 0.88rem;
        text-align: center;
        margin-bottom: 24px;
        padding: 0;
    }
    .auth-input-group {
        position: relative;
        margin-bottom: 18px;
    }
    .auth-input-group .form-control {
        height: 48px;
        border-radius: 14px !important;
        border: 1.5px solid #e8e2d5;
        background: #fdfbf7;
        padding-left: 44px !important;
        padding-right: 16px !important;
        font-size: 0.9rem;
        font-weight: 600;
        color: #1a1a1a;
        transition: all 0.2s ease;
    }
    .auth-input-group .form-control::placeholder {
        color: #9ca3af;
        font-weight: 500;
    }
    .auth-input-group .form-control:focus {
        border-color: #c5a059 !important;
        background: #ffffff !important;
        box-shadow: 0 0 0 4px rgba(197, 160, 89, 0.2) !important;
        outline: none !important;
    }
    .auth-input-group .input-icon {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #c5a059;
        font-size: 1rem;
        z-index: 10;
        pointer-events: none;
    }
    .btn-auth-primary {
        width: 100%;
        height: 48px;
        border-radius: 14px;
        border: none;
        background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%);
        color: #ffffff;
        font-weight: 800;
        font-size: 0.95rem;
        letter-spacing: 0.02em;
        box-shadow: 0 8px 22px rgba(197, 160, 89, 0.35);
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    .btn-auth-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 12px 28px rgba(197, 160, 89, 0.48);
        color: #ffffff;
    }
    .auth-checkbox-label {
        font-size: 0.84rem;
        font-weight: 600;
        color: #685329;
        cursor: pointer;
        user-select: none;
    }
    .auth-link {
        color: #aa7c11;
        font-weight: 700;
        font-size: 0.83rem;
        transition: color 0.15s ease;
        text-decoration: none;
    }
    .auth-link:hover {
        color: #d4af37;
        text-decoration: underline;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="text-align:center;margin-bottom:20px;">
    <h4 style="font-weight:800;color:#1a1a1a;font-size:1.3rem;margin-bottom:4px;letter-spacing:-0.01em;">Welcome Back</h4>
    <p class="login-box-msg">Sign in to start your POS session</p>
</div>

<form action="<?php echo e(route('login')); ?>" method="post">
    <?php echo csrf_field(); ?>
    
    
    <div class="form-group mb-3">
        <div class="auth-input-group">
            <i class="fas fa-envelope input-icon"></i>
            <input type="email" 
                   name="email" 
                   class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="Email Address" 
                   value="<?php echo e(old('email')); ?>" 
                   required 
                   autocomplete="email" 
                   autofocus>
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="form-group mb-3">
        <div class="auth-input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" 
                   class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="Password"
                   name="password" 
                   required 
                   autocomplete="current-password">
        </div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div class="custom-control custom-checkbox" style="display:flex;align-items:center;gap:8px;">
            <input type="checkbox" 
                   name="remember" 
                   id="remember" 
                   style="accent-color:#d4af37;width:17px;height:17px;cursor:pointer;" 
                   <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label for="remember" class="auth-checkbox-label mb-0">
                Remember Me
            </label>
        </div>
    </div>

    <button type="submit" class="btn-auth-primary mb-3">
        <i class="fas fa-sign-in-alt"></i> Sign In
    </button>
</form>

<div style="text-align:center;padding-top:16px;margin-top:12px;border-top:1.5px solid #e8e2d5;display:flex;flex-direction:column;gap:8px;">
    <?php if(Route::has('password.request')): ?>
        <a href="<?php echo e(route('password.request')); ?>" class="auth-link">
            <i class="fas fa-key mr-1" style="font-size:0.75rem;"></i> Forgot your password?
        </a>
    <?php endif; ?>
    <?php if(Route::has('register')): ?>
        <a href="<?php echo e(route('register')); ?>" class="auth-link">
            <i class="fas fa-user-plus mr-1" style="font-size:0.75rem;"></i> Register a new membership
        </a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/auth/login.blade.php ENDPATH**/ ?>