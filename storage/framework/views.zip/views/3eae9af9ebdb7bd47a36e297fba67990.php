

<?php $__env->startSection('title', __('settings.Update_Settings')); ?>
<?php $__env->startSection('content-header', __('settings.Update_Settings')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('settings.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="row">
            <div class="col-md-4 form-group">
                <label for="app_name"><?php echo e(__('settings.app_name')); ?></label>
                <input type="text" name="app_name" class="form-control <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="app_name" placeholder="<?php echo e(__('settings.App_name')); ?>" value="<?php echo e(old('app_name', config('settings.app_name'))); ?>">
                <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 form-group">
                <label for="app_description"><?php echo e(__('settings.app_description')); ?></label>
                <textarea name="app_description" class="form-control <?php $__errorArgs = ['app_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="app_description" placeholder="<?php echo e(__('settings.app_description')); ?>"><?php echo e(old('app_description', config('settings.app_description'))); ?></textarea>
                <?php $__errorArgs = ['app_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 form-group">
                <label for="currency_symbol"><?php echo e(__('settings.Currency_symbol')); ?></label>
                <input type="text" name="currency_symbol" class="form-control <?php $__errorArgs = ['currency_symbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="currency_symbol" placeholder="<?php echo e(__('settings.Currency_symbol')); ?>" value="<?php echo e(old('currency_symbol', config('settings.currency_symbol'))); ?>">
                <?php $__errorArgs = ['currency_symbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4 form-group">
                <label for="warning_quantity"><?php echo e(__('settings.warning_quantity')); ?></label>
                <input type="text" name="warning_quantity" class="form-control <?php $__errorArgs = ['warning_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="warning_quantity" placeholder="<?php echo e(__('settings.warning_quantity')); ?>" value="<?php echo e(old('warning_quantity', config('settings.warning_quantity'))); ?>">
                <?php $__errorArgs = ['warning_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 form-group">
                <label for="show_products">Show Products in Sale Screen</label>
                <select name="show_products" class="form-control <?php $__errorArgs = ['show_products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="show_products">
                    <option value="1" <?php echo e(old('show_products', config('settings.show_products', true)) == 1 ? 'selected' : ''); ?>>Yes</option>
                    <option value="0" <?php echo e(old('show_products', config('settings.show_products', true)) == 0 ? 'selected' : ''); ?>>No</option>
                </select>
            </div>

            <div class="col-md-4 form-group">
                <label for="show_services">Show Services in Sale Screen</label>
                <select name="show_services" class="form-control <?php $__errorArgs = ['show_services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="show_services">
                    <option value="1" <?php echo e(old('show_services', config('settings.show_services', false)) == 1 ? 'selected' : ''); ?>>Yes</option>
                    <option value="0" <?php echo e(old('show_services', config('settings.show_services', false)) == 0 ? 'selected' : ''); ?>>No</option>
                </select>
            </div>

            <div class="col-md-4 form-group">
                <label for="srb_enabled">Enable SRB Fiscal Integration</label>
                <select name="srb_enabled" class="form-control <?php $__errorArgs = ['srb_enabled'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="srb_enabled">
                    <option value="1" <?php echo e(old('srb_enabled', config('settings.srb_enabled', false)) == 1 ? 'selected' : ''); ?>>Yes</option>
                    <option value="0" <?php echo e(old('srb_enabled', config('settings.srb_enabled', false)) == 0 ? 'selected' : ''); ?>>No</option>
                </select>
            </div>

            <div class="col-md-4 form-group">
                <label for="business_logo">Business Logo (Receipt Header)</label>
                <input type="file" name="business_logo" class="form-control-file <?php $__errorArgs = ['business_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="business_logo" accept="image/png,image/jpeg,image/webp">
                <small class="form-text text-muted">PNG, JPG, or WebP; maximum 2 MB.</small>
                <?php if(config('settings.business_logo')): ?>
                    <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url(config('settings.business_logo'))); ?>" alt="Business logo" style="display:block;max-height:54px;max-width:180px;margin-top:8px;object-fit:contain;">
                <?php endif; ?>
                <?php $__errorArgs = ['business_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert"><strong><?php echo e($message); ?></strong></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4 form-group">
                <label for="srb_business_name">SRB Registered Business Name</label>
                <input type="text" name="srb_business_name" class="form-control" id="srb_business_name" value="<?php echo e(old('srb_business_name', config('settings.srb_business_name'))); ?>">
                <small class="form-text text-muted">Use the SRB-registered name, without special characters.</small>
            </div>

            <div class="col-md-4 form-group">
                <label for="srb_ntn">SRB NTN</label>
                <input type="text" name="srb_ntn" class="form-control" id="srb_ntn" value="<?php echo e(old('srb_ntn', config('settings.srb_ntn'))); ?>">
                <small class="form-text text-muted">Enter NTN without a leading S or a hyphen suffix.</small>
            </div>

            <div class="col-md-4 form-group">
                <label for="srb_transaction_type">SRB Transaction Type</label>
                <select name="srb_transaction_type" class="form-control" id="srb_transaction_type">
                    <option value="Test" <?php echo e(old('srb_transaction_type', config('settings.srb_transaction_type', 'Test')) === 'Test' ? 'selected' : ''); ?>>Test</option>
                    <option value="Live" <?php echo e(old('srb_transaction_type', config('settings.srb_transaction_type')) === 'Live' ? 'selected' : ''); ?>>Live</option>
                </select>
            </div>

            <div class="col-md-4 form-group">
                <label for="tax_enabled">Enable Tax on Sale Screen</label>
                <select name="tax_enabled" class="form-control" id="tax_enabled">
                    <option value="1" <?php echo e(old('tax_enabled', config('settings.tax_enabled', false)) == 1 ? 'selected' : ''); ?>>Yes</option>
                    <option value="0" <?php echo e(old('tax_enabled', config('settings.tax_enabled', false)) == 0 ? 'selected' : ''); ?>>No</option>
                </select>
            </div>

            <div class="col-md-4 form-group">
                <label for="discount_enabled">Enable Discount on Sale Screen</label>
                <select name="discount_enabled" class="form-control" id="discount_enabled">
                    <option value="1" <?php echo e(old('discount_enabled', config('settings.discount_enabled', false)) == 1 ? 'selected' : ''); ?>>Yes</option>
                    <option value="0" <?php echo e(old('discount_enabled', config('settings.discount_enabled', false)) == 0 ? 'selected' : ''); ?>>No</option>
                </select>
            </div>

            <div class="form-group">
                <label for="editable_item_rate">Allow Editing Item Rate on Sale Screen</label>
                <select name="editable_item_rate" class="form-control" id="editable_item_rate">
                    <option value="1" <?php echo e(old('editable_item_rate', config('settings.editable_item_rate', false)) == 1 ? 'selected' : ''); ?>>Yes</option>
                    <option value="0" <?php echo e(old('editable_item_rate', config('settings.editable_item_rate', false)) == 0 ? 'selected' : ''); ?>>No</option>
                </select>
            </div>

            </div>

            <div class="col-12 mt-2">
                <button type="submit" class="btn btn-primary"><?php echo e(__('settings.Change_Setting')); ?></button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/settings/edit.blade.php ENDPATH**/ ?>