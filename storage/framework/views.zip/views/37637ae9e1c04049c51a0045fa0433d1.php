<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      
    </div>
    <strong><?php echo e(__('common.Copyright')); ?> &copy; <?php echo e(date('Y')); ?> <a href="http://github.com/aqibinnovative">INPL</a>.</strong> <?php echo e(__('common.all_reserved')); ?>

  </footer>
<?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>