

<?php $__env->startSection('title', __('order.title')); ?>

<?php $__env->startSection('content-header'); ?>
    <span class="pos-screen-title" aria-hidden="true"></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="cart"></div>
    <!--cart></cart-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/cart/index.blade.php ENDPATH**/ ?>