

<?php $__env->startSection('title', 'Permissions'); ?>
<?php $__env->startSection('content-header', 'Permissions'); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $permissions->groupBy('group_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupPerms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mb-3">
    <div class="card-header" style="display:flex;align-items:center;gap:8px;">
        <span style="width:8px;height:8px;border-radius:50%;background:#0ea5b0;display:inline-block;"></span>
        <span style="text-transform:capitalize;font-weight:700;"><?php echo e($group ?? 'General'); ?></span>
        <span class="badge badge-primary ml-1"><?php echo e($groupPerms->count()); ?></span>
    </div>
    <div class="card-body" style="padding:14px 18px;">
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
            <?php $__currentLoopData = $groupPerms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:6px 14px;">
                <span style="font-size:0.8rem;font-weight:600;color:#0ea5b0;"><?php echo e($permission->name); ?></span>
                <?php if($permission->description): ?>
                    <span style="font-size:0.75rem;color:#9ca3af;margin-left:6px;">— <?php echo e($permission->description); ?></span>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/permissions/index.blade.php ENDPATH**/ ?>