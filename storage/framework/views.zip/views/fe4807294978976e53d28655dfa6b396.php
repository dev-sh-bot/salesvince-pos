
<aside class="main-sidebar" id="pos-sidebar">

    
    <a href="<?php echo e(route('home')); ?>" class="brand-link" title="Beauty by GT" style="background:#ffffff!important;border-bottom:1px solid #e8e2d5!important;padding:12px 14px!important;display:flex;align-items:center;gap:10px;text-decoration:none;">
        <div style="width:36px;height:36px;border-radius:12px;background:linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.1rem;box-shadow:0 4px 14px rgba(197,160,89,0.35);flex-shrink:0;">
            <i class="fas fa-gem"></i>
        </div>
        <div style="display:flex;flex-direction:column;min-width:0;">
            <span class="brand-text" style="font-weight:800;font-size:1.05rem;color:#1a1a1a;letter-spacing:-0.02em;line-height:1.1;">
                Beauty <span style="color:#d4af37;">by GT</span>
            </span>
            <span style="font-size:0.55rem;letter-spacing:0.16em;color:#c5a059;text-transform:uppercase;font-weight:800;margin-top:2px;">
                Make-up | Hair | Skin
            </span>
        </div>
    </a>

    <div class="sidebar">
    <nav class="mt-1">
        <ul class="nav nav-pills nav-sidebar flex-column"
            data-widget="treeview"
            role="menu"
            data-accordion="false">
            
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('dashboard.title')); ?>">
                    <a href="<?php echo e(route('home')); ?>"
                       class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>"
                       data-tooltip="<?php echo e(__('dashboard.title')); ?>"
                       title="<?php echo e(__('dashboard.title')); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p><?php echo e(__('dashboard.title')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('product.title')); ?>">
                    <a href="<?php echo e(route('products.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('products')); ?>"
                       data-tooltip="<?php echo e(__('product.title')); ?>"
                       title="<?php echo e(__('product.title')); ?>">
                        <i class="nav-icon fas fa-box-open"></i>
                        <p><?php echo e(__('product.title')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('services.view')): ?>
                <li class="nav-item" data-label="Services">
                    <a href="<?php echo e(route('services.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('services')); ?>"
                       data-tooltip="Services"
                       title="Services">
                        <i class="nav-icon fas fa-spa"></i>
                        <p>Services</p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orders.view')): ?>
                <li class="nav-item sidebar-group-divider" aria-hidden="true"></li>

                
                <li class="nav-item" data-label="<?php echo e(__('POS')); ?>">
                    <a href="<?php echo e(route('cart.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('cart')); ?>"
                       data-tooltip="<?php echo e(__('POS')); ?>"
                       title="<?php echo e(__('POS')); ?>">
                        <i class="nav-icon fas fa-cash-register"></i>
                        <p><?php echo e(__('POS')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>

                
                <li class="nav-item" data-label="<?php echo e(__('Order List')); ?>">
                    <a href="<?php echo e(route('orders.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('orders')); ?>"
                       data-tooltip="<?php echo e(__('Order List')); ?>"
                       title="<?php echo e(__('Order List')); ?>">
                        <i class="nav-icon fas fa-receipt"></i>
                        <p><?php echo e(__('Order List')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customers.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('customer.title')); ?>">
                    <a href="<?php echo e(route('customers.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('customers')); ?>"
                       data-tooltip="<?php echo e(__('customer.title')); ?>"
                       title="<?php echo e(__('customer.title')); ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p><?php echo e(__('customer.title')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.view')): ?>
                <li class="nav-item sidebar-group-divider" aria-hidden="true"></li>

                <li class="nav-item <?php echo e(request()->routeIs('purchases.*') ? 'menu-open' : ''); ?>"
                    data-label="<?php echo e(__('Purchases')); ?>">
                    <a href="#"
                       class="nav-link <?php echo e(activeSegment('purchases')); ?>"
                       data-tooltip="<?php echo e(__('Purchases')); ?>"
                       title="<?php echo e(__('Purchases')); ?>">
                        <i class="nav-icon fas fa-truck-loading"></i>
                        <p><?php echo e(__('Purchases')); ?></p>
                        <i class="right fas fa-angle-down"></i>
                    </a>

                    <ul class="nav nav-treeview" data-header="<?php echo e(__('Purchases')); ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.create')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('purchases.create')); ?>"
                                   class="nav-link <?php echo e(request()->routeIs('purchases.create') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-plus-circle"></i>
                                    <p><?php echo e(__('New Purchase')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.view')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('purchases.index')); ?>"
                                   class="nav-link <?php echo e(request()->routeIs('purchases.index') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-list-ul"></i>
                                    <p><?php echo e(__('All Purchases')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suppliers.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('Supplier')); ?>">
                    <a href="<?php echo e(route('suppliers.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('suppliers')); ?>"
                       data-tooltip="<?php echo e(__('Supplier')); ?>"
                       title="<?php echo e(__('Supplier')); ?>">
                        <i class="nav-icon fas fa-truck"></i>
                        <p><?php echo e(__('Supplier')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('Reports')); ?>">
                    <a href=""
                       class="nav-link <?php echo e(activeSegment('reports')); ?>"
                       data-tooltip="<?php echo e(__('Reports')); ?>"
                       title="<?php echo e(__('Reports')); ?>">
                        <i class="nav-icon fas fa-chart-bar"></i>
                        <p><?php echo e(__('Reports')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branches.view')): ?>
                <li class="nav-item sidebar-group-divider" aria-hidden="true"></li>

                <li class="nav-item" data-label="<?php echo e(__('Branches')); ?>">
                    <a href="<?php echo e(route('branches.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('branches')); ?>"
                       data-tooltip="<?php echo e(__('Branches')); ?>"
                       title="<?php echo e(__('Branches')); ?>">
                        <i class="nav-icon fas fa-code-branch"></i>
                        <p><?php echo e(__('Branches')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('counters.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('Counters')); ?>">
                    <a href="<?php echo e(route('counters.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('counters')); ?>"
                       data-tooltip="<?php echo e(__('Counters')); ?>"
                       title="<?php echo e(__('Counters')); ?>">
                        <i class="nav-icon fas fa-desktop"></i>
                        <p><?php echo e(__('Counters')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('Roles')); ?>">
                    <a href="<?php echo e(route('roles.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('roles')); ?>"
                       data-tooltip="<?php echo e(__('Roles')); ?>"
                       title="<?php echo e(__('Roles')); ?>">
                        <i class="nav-icon fas fa-user-shield"></i>
                        <p><?php echo e(__('Roles')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('Users')); ?>">
                    <a href="<?php echo e(route('users.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('users')); ?>"
                       data-tooltip="<?php echo e(__('Users')); ?>"
                       title="<?php echo e(__('Users')); ?>">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p><?php echo e(__('Users')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.view')): ?>
                <li class="nav-item" data-label="<?php echo e(__('Permissions')); ?>">
                    <a href="<?php echo e(route('permissions.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('permissions')); ?>"
                       data-tooltip="<?php echo e(__('Permissions')); ?>"
                       title="<?php echo e(__('Permissions')); ?>">
                        <i class="nav-icon fas fa-key"></i>
                        <p><?php echo e(__('Permissions')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings.view')): ?>
                <li class="nav-item sidebar-group-divider" aria-hidden="true"></li>

                <li class="nav-item" data-label="<?php echo e(__('settings.title')); ?>">
                    <a href="<?php echo e(route('settings.index')); ?>"
                       class="nav-link <?php echo e(activeSegment('settings')); ?>"
                       data-tooltip="<?php echo e(__('settings.title')); ?>"
                       title="<?php echo e(__('settings.title')); ?>">
                        <i class="nav-icon fas fa-cog"></i>
                        <p><?php echo e(__('settings.title')); ?></p>
                        <i class="right fas fa-angle-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <li class="nav-item" data-label="<?php echo e(__('common.Logout')); ?>">
                <a href="#"
                   class="nav-link nav-link--logout"
                   data-tooltip="<?php echo e(__('common.Logout')); ?>"
                   title="<?php echo e(__('common.Logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('sidebar-logout-form').submit();">
                    <i class="nav-icon fas fa-sign-out-alt"></i>
                    <p><?php echo e(__('common.Logout')); ?></p>
                </a>

                <form action="<?php echo e(route('logout')); ?>"
                      method="POST"
                      id="sidebar-logout-form"
                      class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>

        </ul>
    </nav>
</div>
</aside>


<style>
/* ─────────────────────────────────────────────────────────────
   Beauty by GT — Collapsed Sidebar Hover Flyout Popover
   ───────────────────────────────────────────────────────────── */
@keyframes flyoutSlideIn {
    0% {
        opacity: 0;
        transform: translateY(-50%) translateX(10px);
    }
    100% {
        opacity: 1;
        transform: translateY(-50%) translateX(0);
    }
}

@keyframes treeviewFlyoutSlideIn {
    0% {
        opacity: 0;
        transform: translateX(10px);
    }
    100% {
        opacity: 1;
        transform: translateX(0);
    }
}

body.sidebar-collapse #pos-sidebar,
body.sidebar-collapse aside.main-sidebar,
body.sidebar-collapse .main-sidebar,
body.sidebar-collapse .sidebar,
body.sidebar-collapse .sidebar nav {
    overflow: visible !important;
}

body.sidebar-collapse .main-sidebar .nav-sidebar > .nav-item {
    position: relative !important;
}

/* Tooltip badge for single menu items on hover */
body.sidebar-collapse .main-sidebar .nav-sidebar > .nav-item:not(:has(.nav-treeview)):hover > .nav-link::after {
    content: attr(data-tooltip);
    position: absolute;
    left: 100%;
    top: 50%;
    margin-left: 14px;
    background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%);
    border: 1px solid #d4af37;
    color: #ffffff;
    font-weight: 800;
    font-size: 0.88rem;
    padding: 9px 18px;
    border-radius: 12px;
    white-space: nowrap;
    box-shadow: none !important;
    pointer-events: none;
    z-index: 1090;
    animation: flyoutSlideIn 0.2s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

/* Left pointer arrow for single menu tooltips */
body.sidebar-collapse .main-sidebar .nav-sidebar > .nav-item:not(:has(.nav-treeview)):hover > .nav-link::before {
    content: '';
    position: absolute;
    left: 100%;
    top: 50%;
    transform: translateY(-50%);
    margin-left: 6px;
    border-width: 6px 8px 6px 0;
    border-style: solid;
    border-color: transparent #d4af37 transparent transparent;
    z-index: 1091;
    pointer-events: none;
}

/* Sub-menu Flyout Panel on Hover (e.g. Purchases, Reports) */
body.sidebar-collapse .main-sidebar .nav-sidebar > .nav-item:hover > .nav-treeview {
    display: flex !important;
    flex-direction: column !important;
    position: absolute !important;
    left: 100% !important;
    top: 0 !important;
    margin-left: 12px !important;
    background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%) !important;
    border: 1.5px solid #d4af37 !important;
    border-radius: 18px !important;
    padding: 14px !important;
    min-width: 220px !important;
    box-shadow: none !important;
    z-index: 1090 !important;
    max-height: none !important;
    opacity: 1 !important;
    visibility: visible !important;
    overflow: visible !important;
    animation: treeviewFlyoutSlideIn 0.2s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

/* Flyout Header Title (e.g. Purchases) */
body.sidebar-collapse .main-sidebar .nav-sidebar > .nav-item:hover > .nav-treeview::before {
    content: attr(data-header);
    display: block;
    font-weight: 800;
    font-size: 0.95rem;
    color: #ffffff;
    padding-bottom: 8px;
    margin-bottom: 10px;
    border-bottom: 1.5px solid rgba(255, 255, 255, 0.35);
    letter-spacing: 0.02em;
    text-transform: uppercase;
}

/* Sub-menu links inside flyout */
body.sidebar-collapse .main-sidebar .nav-treeview .nav-item {
    margin: 4px 0 !important;
    width: 100% !important;
    display: block !important;
}

body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link {
    padding: 9px 14px !important;
    font-size: 0.85rem !important;
    background: rgba(255, 255, 255, 0.18) !important;
    border: 1px solid rgba(255, 255, 255, 0.35) !important;
    border-radius: 12px !important;
    color: #ffffff !important;
    font-weight: 700 !important;
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
    transition: all 0.18s ease !important;
}

body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link .nav-icon {
    color: #ffffff !important;
}

body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link p,
body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link span {
    display: inline-block !important;
    opacity: 1 !important;
    width: auto !important;
    visibility: visible !important;
    color: #ffffff !important;
    font-weight: 700 !important;
}

body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link:hover {
    background: #ffffff !important;
    border-color: #ffffff !important;
    color: #aa7c11 !important;
    box-shadow: none !important;
}

body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link:hover p,
body.sidebar-collapse .main-sidebar .nav-treeview .nav-item .nav-link:hover .nav-icon {
    color: #aa7c11 !important;
    font-weight: 800 !important;
}

/* Hide scrollbar completely across browsers */
#pos-sidebar::-webkit-scrollbar,
aside.main-sidebar::-webkit-scrollbar,
.main-sidebar::-webkit-scrollbar,
.sidebar::-webkit-scrollbar,
.main-sidebar .sidebar::-webkit-scrollbar {
    width: 0px !important;
    height: 0px !important;
    display: none !important;
}

#pos-sidebar,
aside.main-sidebar,
.main-sidebar,
.sidebar,
.main-sidebar .sidebar {
    -ms-overflow-style: none !important;
    scrollbar-width: none !important;
}

.brand-link,
.brand-link:hover,
.brand-link:focus,
.brand-link:active,
.main-sidebar .brand-link,
.main-sidebar .brand-link:hover {
    transition: none !important;
    transform: none !important;
    animation: none !important;
    background: #ffffff !important;
    box-shadow: none !important;
}

.brand-link *,
.brand-link:hover * {
    transition: none !important;
    transform: none !important;
    animation: none !important;
}

body:not(.sidebar-collapse) .main-sidebar .brand-link .brand-text,
body:not(.sidebar-collapse) .brand-link .brand-text {
    margin-left: 0 !important;
    padding-left: 0 !important;
    display: block !important;
    white-space: nowrap !important;
}

#pos-sidebar,
aside.main-sidebar,
.main-sidebar {
    background: #ffffff !important;
    border-right: 1.5px solid #e8e2d5 !important;
    box-shadow: 4px 0 24px rgba(197, 160, 89, 0.08) !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link {
    border-radius: 12px !important;
    margin: 3px 6px !important;
    padding: 8px 12px !important;
    background: #fdfbf7 !important;
    border: 1.5px solid #e8e2d5 !important;
    color: #1a1a1a !important;
    font-weight: 700 !important;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link .nav-icon {
    color: #c5a059 !important;
    font-size: 1rem !important;
    margin-right: 10px !important;
    transition: all 0.2s ease !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link p {
    color: #1a1a1a !important;
    font-weight: 700 !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link .right {
    color: #c5a059 !important;
    font-size: 0.78rem !important;
    transition: transform 0.2s ease !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link:hover {
    background: #f5eedf !important;
    border-color: #c5a059 !important;
    color: #8c733e !important;
    box-shadow: 0 4px 14px rgba(197, 160, 89, 0.18) !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link:hover .nav-icon {
    color: #d4af37 !important;
    transform: scale(1.12) !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link:hover p {
    color: #8c733e !important;
}

/* Active Menu Item — Luxury Gold Gradient Pill */
.main-sidebar .nav-sidebar .nav-item .nav-link.active,
.main-sidebar .nav-sidebar .nav-item.menu-open > .nav-link {
    background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%) !important;
    color: #ffffff !important;
    border-color: #d4af37 !important;
    box-shadow: 0 6px 18px rgba(197, 160, 89, 0.38) !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link.active p,
.main-sidebar .nav-sidebar .nav-item.menu-open > .nav-link p {
    color: #ffffff !important;
    font-weight: 800 !important;
}

.main-sidebar .nav-sidebar .nav-item .nav-link.active .nav-icon,
.main-sidebar .nav-sidebar .nav-item .nav-link.active .right,
.main-sidebar .nav-sidebar .nav-item.menu-open > .nav-link .nav-icon,
.main-sidebar .nav-sidebar .nav-item.menu-open > .nav-link .right {
    color: #ffffff !important;
}

/* Treeview Submenu Links */
.main-sidebar .nav-treeview .nav-item .nav-link {
    padding: 8px 12px 8px 34px !important;
    font-size: 0.84rem !important;
    background: #fdfbf7 !important;
    border: 1.5px solid #e8e2d5 !important;
    border-radius: 10px !important;
    color: #1a1a1a !important;
    font-weight: 700 !important;
    margin: 3px 0 !important;
}

.main-sidebar .nav-treeview .nav-item .nav-link .nav-icon {
    color: #c5a059 !important;
}

.main-sidebar .nav-treeview .nav-item .nav-link p {
    color: #1a1a1a !important;
    font-weight: 700 !important;
}

.main-sidebar .nav-treeview .nav-item .nav-link:hover {
    background: #f5eedf !important;
    border-color: #c5a059 !important;
    color: #8c733e !important;
}

.main-sidebar .nav-treeview .nav-item .nav-link:hover .nav-icon,
.main-sidebar .nav-treeview .nav-item .nav-link:hover p {
    color: #8c733e !important;
}

.main-sidebar .nav-treeview .nav-item .nav-link.active {
    background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%) !important;
    color: #ffffff !important;
    border-color: #d4af37 !important;
    box-shadow: 0 4px 14px rgba(197, 160, 89, 0.35) !important;
}

.main-sidebar .nav-treeview .nav-item .nav-link.active .nav-icon,
.main-sidebar .nav-treeview .nav-item .nav-link.active p {
    color: #ffffff !important;
    font-weight: 800 !important;
}

/* Divider Line */
.sidebar-group-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, #e8e2d5, transparent) !important;
    margin: 8px 14px !important;
    pointer-events: none;
}

/* Logout link */
.nav-sidebar .nav-item .nav-link--logout {
    background: #fff5f5 !important;
    border: 1.5px solid #fed7d7 !important;
    color: #dc2626 !important;
}
.nav-sidebar .nav-item .nav-link--logout p {
    color: #dc2626 !important;
}
.nav-sidebar .nav-item .nav-link--logout .nav-icon {
    color: #dc2626 !important;
}
.nav-sidebar .nav-item .nav-link--logout:hover {
    background: #fee2e2 !important;
    border-color: #fca5a5 !important;
}
</style>
<?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>