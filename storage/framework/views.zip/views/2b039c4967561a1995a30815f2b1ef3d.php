
<?php $__env->startSection('title', 'Branches'); ?>
<?php $__env->startSection('content-header', 'Branches'); ?>

<?php $__env->startSection('content-actions'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branches.create')): ?>
        <a href="<?php echo e(route('branches.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus mr-1"></i> Add Branch
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Counters</th>
                    <th>Users</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($branch->id); ?></td>
                    <td>
                        <span style="font-weight:600;color:#0d3b45;"><?php echo e($branch->name); ?></span>
                    </td>
                    <td>
                        <code style="background:#f0f9fa;color:#0ea5b0;padding:2px 8px;border-radius:5px;font-size:0.78rem;">
                            <?php echo e($branch->code); ?>

                        </code>
                    </td>
                    <td style="color:#6b7280;font-size:0.84rem;"><?php echo e($branch->phone ?? '—'); ?></td>
                    <td style="color:#6b7280;font-size:0.84rem;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                        <?php echo e($branch->address ?? '—'); ?>

                    </td>
                    <td><span class="badge badge-primary"><?php echo e($branch->counters_count); ?></span></td>
                    <td><span class="badge badge-secondary"><?php echo e($branch->users_count); ?></span></td>
                    <td>
                        <?php if($branch->is_active): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branches.edit')): ?>
                            <a href="<?php echo e(route('branches.edit', $branch)); ?>" class="btn btn-sm btn-primary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branches.delete')): ?>
                            <button class="btn btn-sm btn-danger btn-delete"
                                    data-url="<?php echo e(route('branches.destroy', $branch)); ?>"
                                    title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center" style="color:#9ca3af;padding:30px 0;">
                        <i class="fas fa-code-branch" style="font-size:2rem;display:block;margin-bottom:8px;color:#d1d5db;"></i>
                        No branches found. <a href="<?php echo e(route('branches.create')); ?>">Create one</a>.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($branches->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).on('click', '.btn-delete', function () {
    const url = $(this).data('url');
    Swal.fire({
        title: 'Delete branch?',
        text: 'All counters in this branch will also be deleted.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete',
        confirmButtonColor: '#ef4444',
        cancelButtonText: 'Cancel',
    }).then(r => {
        if (r.isConfirmed) {
            $.post(url, { _method: 'DELETE', _token: '<?php echo e(csrf_token()); ?>' })
                .done(() => location.reload())
                .fail(xhr => Swal.fire('Error', xhr.responseJSON?.message ?? 'Could not delete.', 'error'));
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/branches/index.blade.php ENDPATH**/ ?>