<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="app-url" content="<?php echo e(url('/')); ?>">

    <title><?php echo $__env->yieldContent('title', config('app.name', 'INPL-POS')); ?></title>

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    
    <?php echo $__env->yieldContent('css'); ?>

    
    <script>
        window.APP = <?php echo json_encode([
            'currency_symbol'  => config('settings.currency_symbol'),
            'app_name'         => config('settings.app_name', config('app.name')),
            'app_description'  => config('settings.app_description', ''),
            'business_logo_url' => config('settings.business_logo')
                ? (\Illuminate\Support\Str::startsWith(config('settings.business_logo'), ['http://', 'https://'])
                    ? config('settings.business_logo')
                    : asset('storage/' . config('settings.business_logo')))
                : null,
            'srb_pos_logo_url' => \Illuminate\Support\Facades\Storage::disk('public')->url('settings/srb-pos-logo.jpg'),
            'warning_quantity' => config('settings.warning_quantity'),
            'show_products'    => (bool) config('settings.show_products', true),
            'show_services'    => (bool) config('settings.show_services', false),
            'srb_enabled'      => (bool) config('settings.srb_enabled', false),
            'tax_enabled'      => (bool) config('settings.tax_enabled', false),
            'discount_enabled' => (bool) config('settings.discount_enabled', false),
            'editable_item_rate' => (bool) config('settings.editable_item_rate', false),
            'locale_cart_url'  => url('/admin/locale/cart'),
            'pos_access' => [
                'status'         => route('pos-access.status'),
                'branches'       => route('pos-access.branches'),
                'verify_branch'  => route('pos-access.verify-branch'),
                'counters'       => route('pos-access.counters'),
                'verify_counter' => route('pos-access.verify-counter'),
                'clear'          => route('pos-access.clear'),
            ],
        ]); ?>;
    </script>
</head>


<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    
    <?php echo $__env->make('layouts.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="content-wrapper">

        
        <section class="content-header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h1><?php echo $__env->yieldContent('content-header'); ?></h1>
                    </div>
                    <div class="col-sm-6 text-right">
                        <?php echo $__env->yieldContent('content-actions'); ?>
                    </div>
                </div>
            </div>
        </section>

        
        <section class="content">
            <?php echo $__env->make('layouts.partials.alert.success', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('layouts.partials.alert.error', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </section>

    </div>
    

    
    <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <aside class="control-sidebar control-sidebar-dark"></aside>

</div>



<?php echo $__env->yieldContent('js'); ?>
<?php echo $__env->yieldContent('model'); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-widget="pushmenu"]');
        if (btn) {
            e.preventDefault();
            e.stopPropagation();
            document.body.classList.toggle('sidebar-collapse');
        }
    });
});
</script>
</body>
</html>
<?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/layouts/admin.blade.php ENDPATH**/ ?>