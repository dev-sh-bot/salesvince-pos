
<nav class="main-header navbar navbar-expand navbar-white navbar-light">

    
    <ul class="navbar-nav align-items-center">
        <li class="nav-item">
            <a class="nav-link px-3"
               data-widget="pushmenu"
               href="#"
               role="button"
               title="Toggle Sidebar">
                <i class="fas fa-bars" style="color:#0f172a;font-size:1rem;"></i>
            </a>
        </li>
        <li class="nav-item d-none d-md-flex align-items-center" style="padding-left:4px;">
            <span class="navbar-brand-text" style="font-weight:800;font-size:0.95rem;color:#0f172a;letter-spacing:0.02em;">
                Beauty <span style="color:#d4af37;">by GT</span>
            </span>
        </li>
    </ul>

    
    <div class="navbar-search d-none d-lg-flex align-items-center ml-3" style="position:relative;">
        <i class="fas fa-search search-icon" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:0.78rem;pointer-events:none;"></i>
        <input type="text"
               class="form-control"
               placeholder="Search..."
               style="padding-left:34px;border-radius:22px;border:1px solid #e2e8f0;background:#f8fafc;width:220px;font-size:0.82rem;">
    </div>

    
    <ul class="navbar-nav ml-auto align-items-center" style="gap:4px;">

        
        <li class="nav-item d-none d-sm-flex align-items-center mr-1">
            <a href="<?php echo e(route('cart.index')); ?>"
               class="btn-pos-pill"
               style="display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 14px;border-radius:20px;background:linear-gradient(135deg,#d4af37 0%,#c5a059 50%,#aa7c11 100%);color:#fff!important;font-size:0.78rem;font-weight:700;text-decoration:none;transition:all 0.15s;box-shadow:0 2px 8px rgba(197,160,89,0.35);line-height:1;border:none;"
               onmouseover="this.style.transform='translateY(-1px)';this.style.boxShadow='0 4px 12px rgba(197,160,89,0.45)'"
               onmouseout="this.style.transform='none';this.style.boxShadow='0 2px 8px rgba(197,160,89,0.35)'">
                <i class="fas fa-cash-register" style="font-size:0.8rem;"></i>
                <span><?php echo e(__('POS')); ?></span>
            </a>
        </li>

        
        <li class="nav-item dropdown">
            <a class="nav-link icon-btn"
               data-toggle="dropdown"
               href="#"
               title="Language"
               style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:10px;color:#64748b;transition:background 0.15s;"
               onmouseover="this.style.background='#fdfbf7';this.style.color='#c5a059'"
               onmouseout="this.style.background='transparent';this.style.color='#64748b'">
                <i class="fas fa-globe" style="font-size:0.95rem;"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right" style="min-width:140px;">
                <div style="padding:6px 12px 4px;font-size:0.7rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.06em;">Language</div>
                <a href="<?php echo e(route('lang.switch', ['lang' => 'en'])); ?>"
                   class="dropdown-item <?php echo e(app()->getLocale() === 'en' ? 'active-lang' : ''); ?>"
                   style="<?php echo e(app()->getLocale() === 'en' ? 'color:#c5a059;font-weight:700;' : ''); ?>">
                    <i class="fas fa-check mr-2" style="<?php echo e(app()->getLocale() === 'en' ? 'color:#c5a059;' : 'visibility:hidden;'); ?>"></i>
                    English
                </a>
                <a href="<?php echo e(route('lang.switch', ['lang' => 'es'])); ?>"
                   class="dropdown-item <?php echo e(app()->getLocale() === 'es' ? 'active-lang' : ''); ?>"
                   style="<?php echo e(app()->getLocale() === 'es' ? 'color:#c5a059;font-weight:700;' : ''); ?>">
                    <i class="fas fa-check mr-2" style="<?php echo e(app()->getLocale() === 'es' ? 'color:#c5a059;' : 'visibility:hidden;'); ?>"></i>
                    Español
                </a>
            </div>
        </li>

        
        <li class="nav-item">
            <button class="icon-btn"
                    title="Notifications"
                    style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:transparent;border:none;color:#64748b;cursor:pointer;position:relative;transition:background 0.15s;"
                    onmouseover="this.style.background='#fdfbf7';this.style.color='#c5a059'"
                    onmouseout="this.style.background='transparent';this.style.color='#64748b'">
                <i class="fas fa-bell" style="font-size:0.95rem;"></i>
                <span style="position:absolute;top:6px;right:6px;width:8px;height:8px;border-radius:50%;background:#d4af37;border:2px solid #fff;"></span>
            </button>
        </li>

        
        <li class="nav-item dropdown ml-1">
            <a class="nav-link p-0"
               data-toggle="dropdown"
               href="#"
               title="<?php echo e(auth()->user()->getFullname()); ?>">
                
                <div style="display:flex;align-items:center;gap:8px;background:#fdfbf7;border:1px solid #e8e2d5;border-radius:24px;padding:4px 12px 4px 4px;cursor:pointer;transition:all 0.15s;"
                     onmouseover="this.style.background='#fff';this.style.borderColor='#c5a059'"
                     onmouseout="this.style.background='#fdfbf7';this.style.borderColor='#e8e2d5'">
                    <div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#d4af37,#aa7c11);color:#fff;display:flex;align-items:center;justify-content:center;font-size:0.78rem;font-weight:700;flex-shrink:0;">
                        <?php echo e(strtoupper(substr(auth()->user()->getFullname(), 0, 1))); ?>

                    </div>
                    <span class="d-none d-md-inline" style="font-size:0.82rem;font-weight:600;color:#0f172a;white-space:nowrap;max-width:110px;overflow:hidden;text-overflow:ellipsis;">
                        <?php echo e(auth()->user()->getFullname()); ?>

                    </span>
                    <i class="fas fa-chevron-down d-none d-md-inline" style="font-size:0.65rem;color:#94a3b8;margin-left:2px;"></i>
                </div>
            </a>

            <div class="dropdown-menu dropdown-menu-right" style="min-width:200px;margin-top:6px;">
                
                <div style="padding:10px 14px 8px;border-bottom:1px solid #f1f5f9;margin-bottom:4px;">
                    <div style="font-size:0.84rem;font-weight:700;color:#0d3b45;"><?php echo e(auth()->user()->getFullname()); ?></div>
                    <div style="font-size:0.75rem;color:#9ca3af;margin-top:1px;"><?php echo e(auth()->user()->email); ?></div>
                </div>

                <a href="<?php echo e(route('settings.index')); ?>" class="dropdown-item">
                    <i class="fas fa-cog" style="width:16px;color:#0ea5b0;"></i>
                    <?php echo e(__('settings.title')); ?>

                </a>

                <a href="<?php echo e(route('home')); ?>" class="dropdown-item">
                    <i class="fas fa-tachometer-alt" style="width:16px;color:#0ea5b0;"></i>
                    <?php echo e(__('dashboard.title')); ?>

                </a>

                <div class="dropdown-divider"></div>

                <a href="#"
                   class="dropdown-item"
                   style="color:#ef4444;"
                   onmouseover="this.style.background='#fef2f2'"
                   onmouseout="this.style.background='transparent'"
                   onclick="event.preventDefault(); document.getElementById('navbar-logout-form').submit();">
                    <i class="fas fa-sign-out-alt" style="width:16px;color:#ef4444;"></i>
                    <?php echo e(__('common.Logout')); ?>

                </a>

                <form id="navbar-logout-form"
                      action="<?php echo e(route('logout')); ?>"
                      method="POST"
                      class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>

    </ul>
</nav>
<?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>