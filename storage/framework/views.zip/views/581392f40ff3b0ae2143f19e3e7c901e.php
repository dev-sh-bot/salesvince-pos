

<?php $__env->startSection('title', 'Roles'); ?>
<?php $__env->startSection('content-header', 'Roles'); ?>

<?php $__env->startSection('content-actions'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create')): ?>
        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus mr-1"></i> Add Role
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table" id="roles-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Description</th>
                    <th>Permissions</th>
                    <th>Users</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($role->id); ?></td>
                    <td>
                        <span class="font-weight-600" style="color:#0d3b45;"><?php echo e($role->name); ?></span>
                        <?php if($role->is_system): ?>
                            <span class="badge badge-info ml-1">System</span>
                        <?php endif; ?>
                    </td>
                    <td><code style="background:#f0f9fa;color:#0ea5b0;padding:2px 7px;border-radius:5px;font-size:0.78rem;"><?php echo e($role->slug); ?></code></td>
                    <td style="color:#6b7280;font-size:0.84rem;"><?php echo e($role->description ?? '—'); ?></td>
                    <td>
                        <span class="badge badge-primary"><?php echo e($role->permissions_count ?? $role->permissions->count()); ?></span>
                    </td>
                    <td>
                        <span class="badge badge-secondary"><?php echo e($role->users_count ?? '—'); ?></span>
                    </td>
                    <td style="font-size:0.82rem;color:#9ca3af;"><?php echo e($role->created_at->format('d M Y')); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.edit')): ?>
                            <a href="<?php echo e(route('roles.edit', $role)); ?>" class="btn btn-sm btn-primary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.delete')): ?>
                            <?php if (! ($role->is_system)): ?>
                                <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="<?php echo e(route('roles.destroy', $role)); ?>"
                                        title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($roles->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).on('click', '.btn-delete', function () {
    const url = $(this).data('url');
    Swal.fire({
        title: 'Delete role?',
        text: 'This action cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete',
        confirmButtonColor: '#ef4444',
        cancelButtonText: 'Cancel',
    }).then(result => {
        if (result.isConfirmed) {
            $.post(url, { _method: 'DELETE', _token: '<?php echo e(csrf_token()); ?>' })
                .done(() => location.reload())
                .fail(xhr => Swal.fire('Error', xhr.responseJSON?.message ?? 'Could not delete.', 'error'));
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/roles/index.blade.php ENDPATH**/ ?>