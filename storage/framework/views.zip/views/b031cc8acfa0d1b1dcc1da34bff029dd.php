

<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content-header', 'Services'); ?>
<?php $__env->startSection('content-actions'); ?>
<a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary">Create Service</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Barcode</th>
                    <th>Rate</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($service->id); ?></td>
                    <td><?php echo e($service->name); ?></td>
                    <td>
                        <img class="product-img" src="<?php echo e($service->image_url); ?>" alt="<?php echo e($service->name); ?>" style="width:48px;height:48px;object-fit:cover;border-radius:8px;">
                    </td>
                    <td><?php echo e($service->barcode ?? '—'); ?></td>
                    <td><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($service->rate, 2)); ?></td>
                    <td>
                        <span class="right badge badge-<?php echo e($service->status ? 'success' : 'danger'); ?>"><?php echo e($service->status ? 'Active' : 'Inactive'); ?></span>
                    </td>
                    <td><?php echo e($service->created_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('services.edit', $service)); ?>" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                        <button class="btn btn-danger btn-delete" data-url="<?php echo e(route('services.destroy', $service)); ?>"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($services->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.addEventListener('click', function (event) {
            const trigger = event.target.closest('.btn-delete');
            if (!trigger) return;

            event.preventDefault();
            const url = trigger.dataset.url;

            Swal.fire({
                title: 'Delete service?',
                text: 'This action cannot be undone.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete',
                cancelButtonText: 'Cancel',
                reverseButtons: true,
            }).then((result) => {
                if (!result.isConfirmed) return;

                fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ _method: 'DELETE' })
                })
                .then(response => response.json())
                .then((res) => {
                    if (res.success) {
                        trigger.closest('tr').remove();
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/services/index.blade.php ENDPATH**/ ?>