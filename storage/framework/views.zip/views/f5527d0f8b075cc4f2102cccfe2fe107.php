
<?php $__env->startSection('title', 'Counters'); ?>
<?php $__env->startSection('content-header', 'Counters'); ?>

<?php $__env->startSection('content-actions'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('counters.create')): ?>
        <a href="<?php echo e(route('counters.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus mr-1"></i> Add Counter
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">

        
        <form method="GET" action="<?php echo e(route('counters.index')); ?>" class="mb-3" style="display:flex;align-items:center;gap:10px;">
            <select name="branch_id" class="form-control" style="max-width:220px;">
                <option value="">All Branches</option>
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->id); ?>" <?php echo e(request('branch_id') == $b->id ? 'selected' : ''); ?>><?php echo e($b->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
            <?php if(request('branch_id')): ?>
                <a href="<?php echo e(route('counters.index')); ?>" class="btn btn-secondary btn-sm">Clear</a>
            <?php endif; ?>
        </form>

        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Branch</th>
                    <th>Counter Name</th>
                    <th>Code</th>
                    <th>Users</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($counter->id); ?></td>
                    <td>
                        <span style="font-size:0.82rem;color:#0ea5b0;font-weight:600;">
                            <?php echo e($counter->branch->name ?? '—'); ?>

                        </span>
                    </td>
                    <td style="font-weight:600;color:#0d3b45;"><?php echo e($counter->name); ?></td>
                    <td>
                        <code style="background:#f0f9fa;color:#0ea5b0;padding:2px 8px;border-radius:5px;font-size:0.78rem;">
                            <?php echo e($counter->code); ?>

                        </code>
                    </td>
                    <td><span class="badge badge-secondary"><?php echo e($counter->users_count); ?></span></td>
                    <td>
                        <?php if($counter->is_active): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('counters.edit')): ?>
                            <a href="<?php echo e(route('counters.edit', $counter)); ?>" class="btn btn-sm btn-primary" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('counters.delete')): ?>
                            <button class="btn btn-sm btn-danger btn-delete"
                                    data-url="<?php echo e(route('counters.destroy', $counter)); ?>"
                                    title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center" style="color:#9ca3af;padding:30px 0;">
                        <i class="fas fa-desktop" style="font-size:2rem;display:block;margin-bottom:8px;color:#d1d5db;"></i>
                        No counters found. <a href="<?php echo e(route('counters.create')); ?>">Create one</a>.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($counters->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).on('click', '.btn-delete', function () {
    const url = $(this).data('url');
    Swal.fire({
        title: 'Delete counter?',
        text: 'This cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete',
        confirmButtonColor: '#ef4444',
    }).then(r => {
        if (r.isConfirmed) {
            $.post(url, { _method: 'DELETE', _token: '<?php echo e(csrf_token()); ?>' })
                .done(() => location.reload())
                .fail(xhr => Swal.fire('Error', xhr.responseJSON?.message ?? 'Could not delete.', 'error'));
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/counters/index.blade.php ENDPATH**/ ?>