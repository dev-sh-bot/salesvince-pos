<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('css'); ?>

    <style>
        body.login-page {
            position: relative !important;
            min-height: 100vh !important;
            margin: 0 !important;
            padding: 0 !important;
            background: linear-gradient(135deg, #ffffff 0%, #faf8f5 50%, #f5efe3 100%) !important;
            overflow-x: hidden !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }

        #interactive-grid-canvas {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            z-index: 0 !important;
            pointer-events: none !important;
        }

        .login-box {
            position: relative !important;
            z-index: 10 !important;
            pointer-events: auto !important;
            width: 100% !important;
            max-width: 440px !important;
            margin: 0 auto !important;
        }

        .login-box .card {
            background: rgba(255, 255, 255, 0.96) !important;
            backdrop-filter: blur(16px) !important;
            border: 2px solid #d4af37 !important;
            border-radius: 24px !important;
            box-shadow: 
                0 0 20px rgba(212, 175, 55, 0.35),
                0 0 40px rgba(197, 160, 89, 0.18),
                0 20px 50px rgba(197, 160, 89, 0.12) !important;
            overflow: hidden !important;
            transition: box-shadow 0.3s ease, border-color 0.3s ease !important;
        }

        .login-box .card:hover {
            box-shadow: 
                0 0 28px rgba(212, 175, 55, 0.48),
                0 0 50px rgba(197, 160, 89, 0.25),
                0 24px 60px rgba(197, 160, 89, 0.18) !important;
        }

        .login-box .card-body {
            padding: 38px 34px !important;
        }
    </style>
</head>

<body class="hold-transition login-page">

    
    <canvas id="interactive-grid-canvas"></canvas>

    <div class="login-box">
        
        
        <div style="text-align:center;margin-bottom:24px;">
            <div style="display:inline-flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:18px;background:linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%);color:#fff;font-size:1.6rem;box-shadow:0 0 20px rgba(212,175,55,0.45);margin-bottom:12px;">
                <i class="fas fa-gem"></i>
            </div>
            <div style="font-weight:800;font-size:1.6rem;color:#1a1a1a;letter-spacing:-0.02em;line-height:1.1;">
                Beauty <span style="color:#d4af37;">by GT</span>
            </div>
            <div style="font-size:0.68rem;letter-spacing:0.22em;color:#c5a059;text-transform:uppercase;font-weight:800;margin-top:4px;">
                Make-up | Hair | Skin
            </div>
        </div>

        <div class="card">
            <div class="card-body login-card-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->

    <script>
        (function() {
            const canvas = document.getElementById('interactive-grid-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            
            let width = canvas.width = window.innerWidth;
            let height = canvas.height = window.innerHeight;
            const cellSize = 60; // Clean, spacious 60px grid boxes

            // Floating luxury gold bokeh glow orbs
            const orbs = [
                { x: width * 0.25, y: height * 0.25, vx: 0.2, vy: 0.15, r: 280, alpha: 0.14 },
                { x: width * 0.75, y: height * 0.70, vx: -0.18, vy: -0.12, r: 320, alpha: 0.12 },
                { x: width * 0.50, y: height * 0.40, vx: 0.12, vy: -0.15, r: 240, alpha: 0.10 },
                { x: width * 0.15, y: height * 0.80, vx: 0.15, vy: 0.20, r: 260, alpha: 0.09 },
                { x: width * 0.85, y: height * 0.20, vx: -0.14, vy: 0.12, r: 300, alpha: 0.11 }
            ];

            window.addEventListener('resize', () => {
                width = canvas.width = window.innerWidth;
                height = canvas.height = window.innerHeight;
            });

            function draw() {
                ctx.clearRect(0, 0, width, height);

                // 1. Draw light luxury pearl background gradient
                const bgGrad = ctx.createLinearGradient(0, 0, width, height);
                bgGrad.addColorStop(0, '#ffffff');
                bgGrad.addColorStop(0.5, '#faf8f5');
                bgGrad.addColorStop(1, '#f5efe3');
                ctx.fillStyle = bgGrad;
                ctx.fillRect(0, 0, width, height);

                // 2. Animate and draw floating ambient gold bokeh orbs
                orbs.forEach(orb => {
                    orb.x += orb.vx;
                    orb.y += orb.vy;

                    // Smooth boundary deflection
                    if (orb.x < -100 || orb.x > width + 100) orb.vx *= -1;
                    if (orb.y < -100 || orb.y > height + 100) orb.vy *= -1;

                    const radG = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.r);
                    radG.addColorStop(0, `rgba(212, 175, 55, ${orb.alpha})`);
                    radG.addColorStop(0.6, `rgba(197, 160, 89, ${orb.alpha * 0.45})`);
                    radG.addColorStop(1, 'transparent');

                    ctx.fillStyle = radG;
                    ctx.fillRect(0, 0, width, height);
                });

                // 3. Draw static clean grid lines on top of glowing bokeh
                ctx.strokeStyle = 'rgba(197, 160, 89, 0.16)';
                ctx.lineWidth = 1;

                ctx.beginPath();
                for (let x = 0; x <= width; x += cellSize) {
                    ctx.moveTo(x, 0);
                    ctx.lineTo(x, height);
                }
                for (let y = 0; y <= height; y += cellSize) {
                    ctx.moveTo(0, y);
                    ctx.lineTo(width, y);
                }
                ctx.stroke();

                requestAnimationFrame(draw);
            }

            draw();
        })();
    </script>

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/layouts/auth.blade.php ENDPATH**/ ?>