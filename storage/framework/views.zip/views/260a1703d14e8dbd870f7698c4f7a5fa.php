<?php $__env->startSection('content-header', ''); ?>
<?php $__env->startSection('content'); ?>
<style>
    /* ── Beauty by GT Luxury Dashboard Design System ── */
    .dashboard-container {
        padding: 0 4px 30px;
    }

    .welcome-banner {
        background: #ffffff;
        border-radius: 20px;
        padding: 22px 26px;
        margin-bottom: 24px;
        border: 1.5px solid #e8e2d5;
        box-shadow: 0 10px 30px rgba(197, 160, 89, 0.08);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 16px;
    }

    .welcome-title h2 {
        font-size: 1.55rem;
        font-weight: 800;
        color: #1a1a1a;
        margin: 0 0 4px;
        letter-spacing: -0.03em;
    }

    .welcome-title p {
        margin: 0;
        font-size: 0.88rem;
        color: #685329;
    }

    .quick-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .btn-quick-action {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 18px;
        border-radius: 12px;
        font-size: 0.84rem;
        font-weight: 700;
        text-decoration: none !important;
        transition: all 0.2s ease;
    }

    .btn-pos-quick {
        background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%);
        color: #ffffff !important;
        box-shadow: 0 6px 18px rgba(197, 160, 89, 0.38);
    }
    .btn-pos-quick:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(197, 160, 89, 0.5);
    }

    .btn-secondary-quick {
        background: #fdfbf7;
        color: #685329 !important;
        border: 1.5px solid #e8e2d5;
    }
    .btn-secondary-quick:hover {
        background: #f5eedf;
        border-color: #c5a059;
        transform: translateY(-2px);
    }

    /* ── Metric Cards ── */
    .metric-card {
        border-radius: 20px;
        padding: 22px;
        color: #ffffff;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .metric-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 14px 34px rgba(197, 160, 89, 0.2);
    }

    .metric-card.card-today {
        background: linear-gradient(135deg, #d4af37 0%, #c5a059 50%, #aa7c11 100%);
    }

    .metric-card.card-week {
        background: linear-gradient(135deg, #1f2229 0%, #111215 100%);
        border: 1.5px solid rgba(197, 160, 89, 0.3);
    }

    .metric-card.card-month {
        background: linear-gradient(135deg, #c5a059 0%, #aa7c11 100%);
    }

    .metric-card.card-customers {
        background: linear-gradient(135deg, #2a251e 0%, #171510 100%);
        border: 1.5px solid rgba(197, 160, 89, 0.3);
    }

    .metric-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 12px;
    }

    .metric-header .icon-bubble {
        width: 44px;
        height: 44px;
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.22);
        backdrop-filter: blur(8px);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }

    .metric-pill {
        padding: 4px 12px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.22);
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }

    .metric-card h3 {
        font-size: 1.7rem;
        font-weight: 800;
        margin: 0 0 4px;
        letter-spacing: -0.02em;
    }

    .metric-card p {
        margin: 0;
        font-size: 0.88rem;
        opacity: 0.92;
        font-weight: 500;
    }

    /* ── Standard Widget Card ── */
    .widget-card {
        background: #ffffff;
        border-radius: 20px;
        border: 1.5px solid #e8e2d5;
        box-shadow: 0 10px 30px rgba(197, 160, 89, 0.06);
        margin-bottom: 24px;
        overflow: hidden;
    }

    .widget-header {
        padding: 18px 22px;
        border-bottom: 1px solid #f5eedf;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #ffffff;
    }

    .widget-header h4 {
        margin: 0;
        font-size: 1.05rem;
        font-weight: 800;
        color: #1a1a1a;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .widget-header .badge-tag {
        font-size: 0.72rem;
        font-weight: 700;
        background: #fdfbf7;
        color: #aa7c11;
        border: 1px solid #e8e2d5;
        padding: 4px 10px;
        border-radius: 8px;
    }

    .chart-container-lg {
        height: 320px;
        padding: 18px 20px;
        position: relative;
    }

    .chart-container-sm {
        height: 320px;
        padding: 18px 20px;
        position: relative;
    }

    /* ── Data Tables ── */
    .table-modern {
        margin-bottom: 0;
    }

    .table-modern thead th {
        background: #fdfbf7;
        color: #685329;
        font-size: 0.74rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        border-top: none;
        border-bottom: 1px solid #e8e2d5;
        padding: 12px 18px;
    }

    .table-modern tbody td {
        padding: 14px 18px;
        font-size: 0.86rem;
        color: #1a1a1a;
        vertical-align: middle;
        border-bottom: 1px solid #f8f6f0;
    }

    .table-modern tbody tr:last-child td {
        border-bottom: none;
    }

    .table-modern tbody tr:hover {
        background-color: #fdfbf7;
    }

    .avatar-badge {
        width: 34px;
        height: 34px;
        border-radius: 10px;
        background: #fdfbf7;
        border: 1px solid #e8e2d5;
        color: #d4af37;
        font-weight: 800;
        font-size: 0.82rem;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-right: 10px;
    }

    .status-pill {
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.02em;
        display: inline-block;
    }

    .status-pill.paid {
        background: #ecfdf5;
        color: #059669;
        border: 1px solid #a7f3d0;
    }

    .status-pill.srb {
        background: #fdfbf7;
        color: #aa7c11;
        border: 1px solid #e8e2d5;
        font-size: 0.7rem;
    }

    .progress-bar-custom {
        height: 6px;
        border-radius: 4px;
        background: #e8e2d5;
        overflow: hidden;
        margin-top: 6px;
    }

    .progress-fill-orange {
        height: 100%;
        background: linear-gradient(90deg, #d4af37, #aa7c11);
        border-radius: 4px;
    }

    .summary-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 13px 0;
        border-bottom: 1px solid #f8f6f0;
    }
    .summary-item:last-child {
        border-bottom: none;
    }
    .summary-item .label {
        font-size: 0.86rem;
        color: #685329;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .summary-item .value {
        font-size: 0.95rem;
        font-weight: 700;
        color: #1a1a1a;
    }
</style>

<div class="dashboard-container">

    
    <div class="welcome-banner">
        <div class="welcome-title">
            <h2>Welcome back, <?php echo e(auth()->user()->first_name ?? 'Admin'); ?>! ✨</h2>
            <p>Here's a comprehensive overview of your sales performance, orders, and real-time inventory.</p>
        </div>
        <div class="quick-actions">
            <a href="<?php echo e(route('cart.index')); ?>" class="btn-quick-action btn-pos-quick">
                <i class="fas fa-cash-register"></i> Open POS Terminal
            </a>
            <a href="<?php echo e(route('products.create')); ?>" class="btn-quick-action btn-secondary-quick">
                <i class="fas fa-plus"></i> Add Product
            </a>
            <a href="<?php echo e(route('customers.create')); ?>" class="btn-quick-action btn-secondary-quick">
                <i class="fas fa-user-plus"></i> New Customer
            </a>
            <a href="<?php echo e(route('orders.index')); ?>" class="btn-quick-action btn-secondary-quick">
                <i class="fas fa-receipt"></i> Orders List
            </a>
        </div>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6 mb-3 mb-xl-0">
            <div class="metric-card card-today">
                <div class="metric-header">
                    <div class="icon-bubble"><i class="fas fa-bolt"></i></div>
                    <span class="metric-pill">Daily Revenue</span>
                </div>
                <div>
                    <h3><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($sales_today, 2)); ?></h3>
                    <p>Today's Sales (<?php echo e($orders_today); ?> orders)</p>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3 mb-xl-0">
            <div class="metric-card card-week">
                <div class="metric-header">
                    <div class="icon-bubble" style="background: rgba(197,160,89,0.2);"><i class="fas fa-chart-line" style="color: #d4af37;"></i></div>
                    <span class="metric-pill" style="background: rgba(197,160,89,0.2); color: #d4af37;">This Week</span>
                </div>
                <div>
                    <h3><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($sales_week, 2)); ?></h3>
                    <p>Weekly Volume (<?php echo e($orders_week); ?> orders)</p>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3 mb-xl-0">
            <div class="metric-card card-month">
                <div class="metric-header">
                    <div class="icon-bubble"><i class="fas fa-calendar-alt"></i></div>
                    <span class="metric-pill"><?php echo e($mom_growth >= 0 ? '+' : ''); ?><?php echo e($mom_growth); ?>% MoM</span>
                </div>
                <div>
                    <h3><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($sales_month, 2)); ?></h3>
                    <p>Monthly Sales (<?php echo e($orders_month); ?> orders)</p>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="metric-card card-customers">
                <div class="metric-header">
                    <div class="icon-bubble" style="background: rgba(197,160,89,0.2);"><i class="fas fa-users" style="color: #d4af37;"></i></div>
                    <span class="metric-pill" style="background: rgba(197,160,89,0.2); color: #d4af37;">Customer Hub</span>
                </div>
                <div>
                    <h3><?php echo e($customers_count); ?> Registered</h3>
                    <p><?php echo e($orders_count); ?> Total Completed Orders</p>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        
        <div class="col-lg-8">
            <div class="widget-card">
                <div class="widget-header">
                    <h4><i class="fas fa-chart-area" style="color: #d4af37;"></i> 12-Month Revenue & Orders Trajectory</h4>
                    <span class="badge-tag">Past 12 Months Analytics</span>
                </div>
                <div class="chart-container-lg">
                    <canvas id="monthlySalesChart"></canvas>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4">
            <div class="widget-card">
                <div class="widget-header">
                    <h4><i class="fas fa-chart-pie" style="color: #c5a059;"></i> Category & Service Share</h4>
                    <span class="badge-tag">Volume Distribution</span>
                </div>
                <div class="chart-container-sm">
                    <canvas id="serviceSalesChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        
        <div class="col-lg-7">
            <div class="widget-card">
                <div class="widget-header">
                    <h4><i class="fas fa-shopping-bag" style="color: #d4af37;"></i> Latest Transactions</h4>
                    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-xs" style="background: #fdfbf7; border: 1px solid #e8e2d5; color: #aa7c11; border-radius: 8px; font-weight: 700;">View All Orders</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-modern">
                        <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Customer</th>
                                <th>Items</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <span style="font-weight: 700; color: #1a1a1a;">#ORD-<?php echo e($ord->id); ?></span>
                                        <?php if($ord->srb_invoice_id): ?>
                                            <div class="status-pill srb"><?php echo e($ord->srb_invoice_id); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-badge">
                                                <?php echo e(strtoupper(substr($ord->customer->first_name ?? 'Walk-in', 0, 1))); ?>

                                            </div>
                                            <div>
                                                <div style="font-weight: 600; color: #1a1a1a;">
                                                    <?php echo e($ord->customer ? $ord->customer->first_name . ' ' . $ord->customer->last_name : 'Walk-in Customer'); ?>

                                                </div>
                                                <small style="color: #685329;"><?php echo e($ord->customer->phone ?? '—'); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge badge-light" style="font-size: 0.8rem; font-weight: 600; background: #fdfbf7; border: 1px solid #e8e2d5; color: #685329;"><?php echo e($ord->items->sum('quantity')); ?> items</span>
                                    </td>
                                    <td>
                                        <strong style="color: #c5a059; font-size: 0.92rem; font-weight: 800;">
                                            <?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($ord->total_amount, 2)); ?>

                                        </strong>
                                    </td>
                                    <td>
                                        <span class="status-pill paid"><i class="fas fa-check-circle mr-1"></i> Paid</span>
                                    </td>
                                    <td style="color: #685329; font-size: 0.8rem;">
                                        <?php echo e($ord->created_at ? $ord->created_at->format('d M, h:i A') : '—'); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">No recent transactions recorded</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="col-lg-5">
            <div class="widget-card">
                <div class="widget-header">
                    <h4><i class="fas fa-fire" style="color: #d4af37;"></i> Top Selling Items</h4>
                    <span class="badge-tag">High Demand</span>
                </div>
                <div class="p-3">
                    <?php $__empty_1 = true; $__currentLoopData = $top_selling_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span style="font-weight: 600; font-size: 0.88rem; color: #1a1a1a;"><?php echo e($item['name']); ?></span>
                                <span style="font-weight: 700; font-size: 0.86rem; color: #c5a059;"><?php echo e($item['quantity']); ?> sold</span>
                            </div>
                            <div class="progress-bar-custom">
                                <div class="progress-fill-orange" style="width: <?php echo e(min(100, max(20, $item['quantity'] * 2))); ?>%;"></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-4 text-muted">No sales items recorded</div>
                    <?php endif; ?>
                </div>

                <?php if($low_stock_products->isNotEmpty()): ?>
                    <div class="p-3 border-top" style="background: #fdfbf7;">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span style="font-size: 0.82rem; font-weight: 700; color: #dc2626;"><i class="fas fa-exclamation-triangle mr-1"></i> Low Stock Alert</span>
                            <a href="<?php echo e(route('products.index')); ?>" class="small" style="color: #dc2626; font-weight: 600;">Manage Inventory</a>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <?php $__currentLoopData = $low_stock_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lsp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-danger p-2" style="border-radius: 6px; font-weight: 500; font-size: 0.76rem;">
                                    <?php echo e($lsp->name); ?> (<?php echo e($lsp->quantity); ?> left)
                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="row">
        
        <div class="col-lg-8">
            <div class="widget-card">
                <div class="widget-header">
                    <h4><i class="fas fa-table" style="color: #c5a059;"></i> Monthly Financial Breakdown</h4>
                    <span class="badge-tag">Audited Log</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-modern">
                        <thead>
                            <tr>
                                <th>Billing Month</th>
                                <th>Total Orders</th>
                                <th>Gross Revenue</th>
                                <th>Avg Ticket Value</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $monthly_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($month['label']); ?></strong></td>
                                    <td><span class="badge badge-light" style="font-size: 0.82rem; font-weight: 600; background: #fdfbf7; border: 1px solid #e8e2d5; color: #685329;"><?php echo e($month['orders']); ?> orders</span></td>
                                    <td><strong style="color: #1a1a1a;"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($month['sales'], 2)); ?></strong></td>
                                    <td style="color: #685329;"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($month['orders'] ? $month['sales'] / $month['orders'] : 0, 2)); ?></td>
                                    <td>
                                        <span class="status-pill paid"><i class="fas fa-check-double mr-1"></i> Closed</span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4">
            <div class="widget-card">
                <div class="widget-header">
                    <h4><i class="fas fa-calculator" style="color: #d4af37;"></i> Current Month POS Audit</h4>
                    <span class="badge-tag"><?php echo e(now()->format('M Y')); ?></span>
                </div>
                <div class="p-3">
                    <div class="summary-item">
                        <span class="label"><i class="fas fa-box" style="color: #c5a059;"></i> Items Dispatched</span>
                        <span class="value"><?php echo e(number_format($pos_summary['items_sold'])); ?> units</span>
                    </div>
                    <div class="summary-item">
                        <span class="label"><i class="fas fa-receipt" style="color: #c5a059;"></i> Average Basket Size</span>
                        <span class="value"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($pos_summary['average_order'], 2)); ?></span>
                    </div>
                    <div class="summary-item">
                        <span class="label"><i class="fas fa-percent" style="color: #c5a059;"></i> Tax Collected (SRB)</span>
                        <span class="value" style="color: #059669;"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($pos_summary['tax'], 2)); ?></span>
                    </div>
                    <div class="summary-item">
                        <span class="label"><i class="fas fa-tag" style="color: #c5a059;"></i> Discounts Claimed</span>
                        <span class="value" style="color: #aa7c11;"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($pos_summary['discount'], 2)); ?></span>
                    </div>
                    <div class="summary-item" style="background: #fdfbf7; border: 1px solid #e8e2d5; padding: 12px 14px; border-radius: 12px; margin-top: 10px;">
                        <span class="label" style="font-weight: 700; color: #1a1a1a;"><i class="fas fa-wallet" style="color: #d4af37;"></i> Total Net Inflow</span>
                        <span class="value" style="color: #c5a059; font-size: 1.1rem; font-weight: 800;"><?php echo e(config('settings.currency_symbol')); ?> <?php echo e(number_format($sales_month, 2)); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const currency = <?php echo json_encode(config('settings.currency_symbol'), 15, 512) ?>;
    const monthly = <?php echo json_encode($monthly_sales, 15, 512) ?>;
    const services = <?php echo json_encode($service_sales, 15, 512) ?>;

    // 1. Monthly Sales & Orders Combined Bar + Area Chart
    const ctxMonthly = document.getElementById('monthlySalesChart');
    if (ctxMonthly) {
        const labels = monthly.map(m => m.label);
        const salesData = monthly.map(m => m.sales);
        const ordersData = monthly.map(m => m.orders);

        new Chart(ctxMonthly, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Gross Sales (' + currency + ')',
                        data: salesData,
                        backgroundColor: 'rgba(212, 175, 55, 0.85)',
                        borderColor: '#d4af37',
                        borderWidth: 1,
                        borderRadius: 8,
                        barPercentage: 0.6,
                        yAxisID: 'ySales'
                    },
                    {
                        label: 'Orders Count',
                        data: ordersData,
                        type: 'line',
                        borderColor: '#c5a059',
                        backgroundColor: 'rgba(197, 160, 89, 0.12)',
                        borderWidth: 3,
                        pointBackgroundColor: '#c5a059',
                        pointBorderColor: '#ffffff',
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        tension: 0.38,
                        fill: true,
                        yAxisID: 'yOrders'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            font: { family: 'Inter', size: 12, weight: '600' },
                            color: '#685329',
                            usePointStyle: true,
                            boxWidth: 8
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 26, 26, 0.94)',
                        titleFont: { family: 'Inter', size: 13, weight: '700' },
                        bodyFont: { family: 'Inter', size: 12 },
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: function(context) {
                                if (context.dataset.yAxisID === 'ySales') {
                                    return 'Sales: ' + currency + ' ' + context.parsed.y.toLocaleString();
                                }
                                return 'Orders: ' + context.parsed.y + ' orders';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { font: { family: 'Inter', size: 11 }, color: '#685329' }
                    },
                    ySales: {
                        type: 'linear',
                        position: 'left',
                        beginAtZero: true,
                        grid: { color: '#f8f6f0' },
                        ticks: {
                            font: { family: 'Inter', size: 11 },
                            color: '#685329',
                            callback: value => currency + ' ' + (value >= 1000 ? (value/1000) + 'k' : value)
                        }
                    },
                    yOrders: {
                        type: 'linear',
                        position: 'right',
                        beginAtZero: true,
                        grid: { drawOnChartArea: false },
                        ticks: {
                            font: { family: 'Inter', size: 11 },
                            color: '#c5a059',
                            stepSize: 10
                        }
                    }
                }
            }
        });
    }

    // 2. Category & Service Doughnut Chart
    const ctxService = document.getElementById('serviceSalesChart');
    if (ctxService) {
        const serviceKeys = Object.keys(services);
        const serviceValues = Object.values(services);

        const chartColors = [
            '#d4af37', '#c5a059', '#aa7c11', '#1a1a1a', 
            '#8c733e', '#e8e2d5', '#524320', '#b8860b'
        ];

        new Chart(ctxService, {
            type: 'doughnut',
            data: {
                labels: serviceKeys.length ? serviceKeys : ['General Products', 'Beverages', 'Services'],
                datasets: [{
                    data: serviceValues.length ? serviceValues : [65, 25, 10],
                    backgroundColor: chartColors.slice(0, Math.max(serviceKeys.length, 3)),
                    borderWidth: 2,
                    borderColor: '#ffffff',
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: { family: 'Inter', size: 11, weight: '500' },
                            color: '#685329',
                            usePointStyle: true,
                            boxWidth: 8,
                            padding: 14
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 26, 26, 0.94)',
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + currency + ' ' + Number(context.parsed).toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\POS-INPL\inpl-pos\resources\views/home.blade.php ENDPATH**/ ?>